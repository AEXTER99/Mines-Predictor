let grid = [];
let minePositions = new Set();
let revealed = new Set();
let size = 5;

function startGame() {
  const mineCount = parseInt(document.getElementById("mineCount").value);
  const total = size * size;
  minePositions = new Set();
  revealed = new Set();
  grid = [];

  while (minePositions.size < mineCount) {
    minePositions.add(Math.floor(Math.random() * total));
  }

  const gridContainer = document.getElementById("grid");
  gridContainer.innerHTML = '';
  for (let i = 0; i < total; i++) {
    const btn = document.createElement("button");
    btn.className = "tile";
    btn.innerText = '';
    btn.onclick = () => handleClick(i, btn);
    gridContainer.appendChild(btn);
    grid.push(btn);
  }

  document.getElementById("status").innerText = `Game started with ${mineCount} mines.`;
}

function handleClick(index, btn) {
  if (minePositions.has(index)) {
    btn.classList.add("mine");
    btn.innerText = "💣";
    document.getElementById("status").innerText = "Oops! You hit a mine.";
    revealAll();
  } else {
    btn.classList.add("revealed");
    btn.disabled = true;
    revealed.add(index);
    document.getElementById("status").innerText = `Safe! ${revealed.size} revealed.`;
  }
}

function revealAll() {
  for (let i = 0; i < grid.length; i++) {
    if (minePositions.has(i)) {
      grid[i].classList.add("mine");
      grid[i].innerText = "💣";
    }
    grid[i].disabled = true;
  }
}